#include "Solution.h"

int main()
{
	Solution solution;

	std::vector<int> nums = {0,-1,2,-3,1};


	solution.Display(nums);
	
}
